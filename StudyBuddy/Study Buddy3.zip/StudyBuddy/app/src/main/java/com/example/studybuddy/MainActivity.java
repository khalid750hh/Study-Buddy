package com.example.studybuddy;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;

import com.firebase.ui.auth.data.model.User;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private static final int RC_SIGN_IN = 9999;
    private TextView txt1, txt2;
    private FirebaseAuth mAuth;
    private GoogleSignInClient mGoogleSignInClient;
    private SignInButton signInButton;
    private Button signOutButton;
    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference myRef = database.getReference("users");
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private GoogleSignInAccount userAccount;
    private WebView userImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().hide();
        // Configure views
        txt1 = (TextView) findViewById(R.id.textView1);
        txt2 = (TextView) findViewById(R.id.textView2);
        signOutButton = (Button) findViewById(R.id.sign_out_button);
        userImage = (WebView) findViewById(R.id.userImage);
        userImage.getSettings().setJavaScriptEnabled(true);
        // Configure Google Sign In
        GoogleSignInOptions gso = new GoogleSignInOptions
                .Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        // Build a GoogleSignInClient with the options specified by gso.
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        // ...
        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();
        //Configuring sign in button
        signInButton = findViewById(R.id.sign_in_button);
        signInButton.setSize(SignInButton.SIZE_STANDARD);
        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.sign_in_button:
                        signIn();
                        break;
                    // ...
                }
            }
        });
        //sign out button onclick method
        signOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    signOut();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
        try {
            updateUI(account);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                handleSignInResult(task);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) throws IOException {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);
            // Signed in successfully, show authenticated UI.
            updateUI(account);
        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            Log.w(TAG, "signInResult:failed code=" + e.getStatusCode());
            updateUI(null);
        }
    }

    private void signIn() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }
    private void signOut() throws IOException {
        //Intent signOutIntent =
        mGoogleSignInClient.signOut();
        //startActivityForResult(signOutIntent, RC_SIGN_OUT);
        updateUI(null);
    }

    private void updateUI(GoogleSignInAccount account) throws IOException {
        if(account == null){
            signInButton.setClickable(true);
            signInButton.setVisibility(View.VISIBLE);
            signOutButton.setClickable(false);
            signOutButton.setVisibility((View.GONE));
            txt1.setText("Please sign in using the button above!");
            txt2.setText("Not signed in!");
            userImage.clearView();

        }
        else{
            signInButton.setClickable(false);
            signInButton.setVisibility(View.GONE);
            signOutButton.setVisibility(View.VISIBLE);
            signOutButton.setClickable(true);
            txt1.setText("You can sign out using the button above!");
            sendUserInfoToDatabase(account);
            Intent goToChat = new Intent(this, UserList.class);
            goToChat.putExtra("user id", userAccount.getId());
            goToChat.putExtra("user name", userAccount.getDisplayName());
            goToChat.putExtra("user email", userAccount.getEmail());
            goToChat.putExtra("user picture url", userAccount.getPhotoUrl().toString());
            startActivity(goToChat);
        }

    }

    private void sendUserInfoToDatabase(GoogleSignInAccount account) throws IOException {
        userAccount = account;

//        DatabaseReference userRef = myRef.child("users");
//        Map<String, StudentUser> users = new HashMap<>();
//        users.put(account.getId(), new StudentUser(account.getPhotoUrl().toString(),
//                account.getGivenName() + " " + account.getFamilyName(),
//                account.getDisplayName(),
//                account.getEmail()));
//        myRef.child(userAccount.getId()).setValue(users);
        myRef.child(userAccount.getId()).setValue(new StudentUser(userAccount.getPhotoUrl().toString(),
                userAccount.getGivenName() + " " + userAccount.getFamilyName(),
                userAccount.getDisplayName(), userAccount.getEmail(),
                userAccount.getId()));

//        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
//            @RequiresApi(api = Build.VERSION_CODES.N)
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                if (snapshot.exists()){
//                    Log.e("database22222", "hi");
//                    Map<String, ?> data = (Map<String, Map<String, ?>>) snapshot.getValue();
//                    Map<String, Map<String, String>> map = (Map<String, Map<String, String>>) data.get((userAccount.getId()));
//                    String name = map.get(userAccount.getId()).get(("full_name"));
//                    String email = map.get(userAccount.getId()).get(("e_mail"));
//                    String picture = map.get(userAccount.getId()).get(("image_of_user"));
//                    txt2.setText("Welcome " + name + " " + email);
//                    userImage.loadUrl(picture);
//                }
//                else{
//                    txt2.setText("l");
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
    }
}