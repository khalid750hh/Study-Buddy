package com.example.studybuddy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseListAdapter;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.math.BigInteger;

public class UserList extends AppCompatActivity {

    private String thisUserId;
    private String email;
    private String name;
    private String photo;

    private ListView listViewUsers;
    private FirebaseListAdapter<StudentUser> adapter;
    private DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("users");

    private long remove;

    private GoogleSignInClient mGoogleSignInClient;

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
//        mGoogleSignInClient.signOut();
//        finish();
    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_list);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        Intent extras = getIntent();
        thisUserId = extras.getStringExtra("user id");
        email = extras.getStringExtra("user email");
        name = extras.getStringExtra("user name");
        photo = extras.getStringExtra("user picture url");

        GoogleSignInOptions gso = new GoogleSignInOptions
                .Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        // Build a GoogleSignInClient with the options specified by gso.
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);



        listViewUsers = (ListView) findViewById(R.id.listViewUsers);
//        Button backButton = (Button)this.findViewById(R.id.back);




        try {
            displayAppUsers();
        }
        catch (Exception e){

        }



        listViewUsers.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

//                int uid = view.getId();
//                String userId = view.findViewById(R.id.id_user);

                StudentUser v = (StudentUser) adapterView.getItemAtPosition(i);

                String userEmail = v.getE_mail();
                String userName = v.getFull_name();
                String userId = v.getId();
                String otherUser = userId;

                Intent goToChat = new Intent(getApplicationContext(), MainActivityChat.class);
                goToChat.putExtra("user id", thisUserId);
                goToChat.putExtra("user name", name);
                goToChat.putExtra("user email", email);
                goToChat.putExtra("user picture url", photo);
                for (int x = 0; x < 3; x++) {
                    int y = x*7;
                    int compareThisId = Integer.parseInt(thisUserId.substring(y, y + 7));
                    int compareOtherId = Integer.parseInt(otherUser.substring(y, y + 7));
                    Log.e("studybuddy555", compareThisId + " " + compareOtherId);
                    if (compareThisId > compareOtherId){
                        goToChat.putExtra("chat id", thisUserId+otherUser);
                        break;
                    }
                    else if (compareThisId < compareOtherId){
                        goToChat.putExtra("chat id", otherUser+thisUserId);
                        break;
                    }

                    else if (x == 2){
                        goToChat.putExtra("chat id", otherUser+thisUserId);
                        break;
                    }
                }

                startActivity(goToChat);
            }
        });


    }

    private void displayAppUsers() {

        adapter = new FirebaseListAdapter<StudentUser>(this, StudentUser.class,
                R.layout.users, usersRef) {
            @Override
            protected void populateView(View v, StudentUser model, int position) {
//                if(model.getId().toString().equals(thisUserId) == false){
//                    TextView userEmail = (TextView) v.findViewById(R.id.email_user);
//                    TextView userName = (TextView) v.findViewById(R.id.name_user);
//                    TextView userId = (TextView) v.findViewById(R.id.id_user);
//
//                    userEmail.setText(model.getE_mail());
//                    userName.setText(model.getFull_name());
//                    userId.setText(model.getId());
//                }
//                else{
//                    remove = adapter.getItemId(position);
//                }
                TextView userEmail = (TextView) v.findViewById(R.id.email_user);
                TextView userName = (TextView) v.findViewById(R.id.name_user);
                TextView userId = (TextView) v.findViewById(R.id.id_user);

                userEmail.setText(model.getE_mail());
                userName.setText(model.getFull_name());
                userId.setText(model.getId());

//                if(userId.getText().toString().equals(thisUserId)){
//                    Toast.makeText(getBaseContext(), position + "", Toast.LENGTH_SHORT).show();
//                    remove = position;
//                    v = null;
//                    model = null;
//                }

            }
        };
//        adapter.getItem(remove) = null;
        listViewUsers.setAdapter(adapter);
//        listViewUsers.getItemIdAtPosition((int) remove);
//        listViewUsers.removeViewAt((int) remove);
//        listViewUsers.removeViewAt(remove);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //Inflate the menu; this adds items to the action bar if it is present.
        //Unfortunately there is no full blown menu editor, eg, like the layout or strings editor in the IDE.
        //Must enter the menu items manually.
        getMenuInflater().inflate(R.menu.signoutmenu, menu);

        return true;  //we've handled it!
    }

    //Override onOptionsItemSelected(..) to handle menu clicks by the user
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.signOut) {
            mGoogleSignInClient.signOut();
            finish();
            Toast.makeText(getBaseContext(), "Signed Out!", Toast.LENGTH_SHORT).show();
            return true;
        }

//            …
        return super.onOptionsItemSelected(item);  //default behavior (fall through), shouldn't really get here tho, why?

    }
}