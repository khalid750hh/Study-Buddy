package com.example.studybuddy;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;

import com.firebase.ui.auth.data.model.User;
import com.firebase.ui.database.FirebaseListAdapter;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.DateFormat;

public class MainActivityChat extends AppCompatActivity {

    private String id;
    private String email;
    private String name;
    private String photo;
    private String chatID;

    private TextView txtMessage;
    private FloatingActionButton btnSend;
    private ListView listViewChat;
    private FirebaseListAdapter<ChatMessage> adapter;
    private DatabaseReference myRef = FirebaseDatabase.getInstance().getReference("chatrooms");
    private DatabaseReference chatroomRef;

    private String lastId = null;
    private String lastYear = null;
    private String lastMonth = null;
    private String lastDay = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_chat);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().hide();
        Intent extras = getIntent();
        id = extras.getStringExtra("user id");
        email = extras.getStringExtra("user email");
        name = extras.getStringExtra("user name");
        photo = extras.getStringExtra("user picture url");
        chatID = extras.getStringExtra("chat id");

        chatroomRef = myRef.child(chatID);


        txtMessage = (TextView) findViewById(R.id.txtMessage);
        btnSend = (FloatingActionButton) findViewById(R.id.btnSend);
        listViewChat = (ListView) findViewById(R.id.listViewChat);

        displayChatMessages();


        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(txtMessage.getText().toString().replaceAll("\\s", "").isEmpty() == false){
                    ChatMessage message = new ChatMessage(txtMessage.getText().toString(), name, id);
                    Log.e("studybuddy555", chatroomRef.getKey());
//                    chatroomRef.
                    DatabaseReference messageRef = chatroomRef.push();
                    messageRef.setValue(message);

                    txtMessage.setText("");
                }
            }
        });
    }

    private void displayChatMessages(){
        adapter = new FirebaseListAdapter<ChatMessage>(this, ChatMessage.class,
                R.layout.message, chatroomRef) {
            @Override
            protected void populateView(View v, ChatMessage model, int position) {
                String messageId = model.getUserId();

                TextView messageText = (TextView) v.findViewById(R.id.message_text);
                TextView messageUser = (TextView) v.findViewById(R.id.message_user);
                TextView messageTime = (TextView) v.findViewById(R.id.message_time);

                messageText.setText(model.getMessageText());
                if (messageId.equals(id)){
                    //messageText.setBackgroundColor(0x1CC8F3);
                    //messageText.setBackgroundResource(R.color.black);
                    v.setBackgroundResource(R.color.teal_200);
                }
                messageUser.setText(model.getMessageUser());

                android.text.format.DateFormat df = new android.text.format.DateFormat();

                messageTime.setText(df.format("dd-MM-yy HH:mm",
                            model.getMessageTime()));

//                if (lastYear == null){
//                    messageTime.setText(df.format("dd-MM-yy HH:mm",
//                            model.getMessageTime()));
//                    lastDay = df.format("dd", model.getMessageTime()).toString();
//                    lastMonth = df.format("MM", model.getMessageTime()).toString();
//                    lastYear = df.format("yy", model.getMessageTime()).toString();
//                }
//                else{
//                    if ( df.format("yy", model.getMessageTime()).toString().equals(lastYear)
//                    && df.format("MM", model.getMessageTime()).toString().equals(lastMonth)
//                    && df.format("dd", model.getMessageTime()).toString().equals(lastDay)){
//                                messageTime.setText(df.format("HH:mm",
//                                        model.getMessageTime()));
//                            }
//                    else{
//                        messageTime.setText(df.format("dd-MM-yy HH:mm",
//                                model.getMessageTime()));
//                    }
//                }
            }
        };
        listViewChat.setAdapter(adapter);
        listViewChat.setDivider(null);
    }
}